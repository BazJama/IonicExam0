import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subpage',
  templateUrl: './subpage.page.html',
  styleUrls: ['./subpage.page.scss'],
})
export class SubpagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
