import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TabsPageRoutingModule } from './tabs.router.module';
import { RouterModule } from '@angular/router';

import { TabsPage } from './tabs.page';
import { SubpagePage } from '../tab1/service/subpage/subpage.page';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    TabsPageRoutingModule,
    RouterModule.forChild([
       { path: '', component: SubpagePage},
       { path: 'subpage', loadChildren: './subpage/subpage.module#SubpagePageModule' },
       ])
  ],
  declarations: [TabsPage]
})
export class TabsPageModule {}
